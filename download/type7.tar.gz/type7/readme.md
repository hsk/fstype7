# type7コンパイラ

## はじめに

このコンパイラはFSharpで作成したLLVMを利用したネイティブコンパイラです。

- [TODOリスト](todo.md)
- [履歴](history.md)


## ダウンロード

ダウンロード: [type7.tar.gz](https://github.com/hsk/fstype7/raw/master/download/type7.tar.gz)
